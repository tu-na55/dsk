
___
### 半角 / 全角
Win-US
+  alt + `

Mac-US
+ コマンドキーcontrolを押しながら、スペースキーを押すとその度に切り替わります。
+ Karabinerで、スペースキーの左右にあるコマンドキーを空撃ちでJIS環境と同じ環境に変更することができます。
+ shift + j


+ 違いは実は2つしか違いません。
  + US：74+矢印キー
  + JIS：76+矢印キー


+ `・`: 日本語入力状態で、`/`（ATOK、Google日本語入力の場合）



___
### key-customizeまとめ
非推奨。

HHKB
+ ON
  + No1: Win-mode
  + No3: backspace
  + No5: 左からWin_key, alt/optionの順にする。

共通
```
+ `alt/option`空打ち
  + Win_note: "_"<73> => `
  + HHKB: "右command" => `
    + これだとミスタッチが多いので、Win版カラビナを作ってくれた人のを使う。
+ `\ or |`, `accent_grave or ~`がどこにあるのか把握すること。

Win
+ "caps" => `ctrl`
+ JP(hard)-JP(soft): "全角" => `esc`

Mac
+ "caps" or "ctrl" => `command`
+ "command" => `alt/option`
+ "alt/option" => `ctrl`
```

___

##### Win
  + `F11`: full screen
    + win + 上
```
Escapeキーは大体なんでもキャンセルできる。
Tabキーは大体フォーカスを移動できる。Shift + Tabでフォーカスを逆順に移動できる。

▼アプリケーションの立ち上げかた
重要。Windowsキー押してアプリケーション名をタイプしてEnterするとそれが立ち上がる。そして、Visual Studio Codeやらにフォーカスしている状態でアプリケーションキーやらShift + F10やらを押下するとコンテキストメニューが開く。そこには最近使用したアレコレが表示される。

これを駆使出来ればタスクバーもデスクトップも汚れづらい。

サクラエディタもSnipping Toolもエクスプローラーもすぐに立ち上げられるぜ。

▼Alt + Tab
クッソ重要。作業アプリケーション/ウィンドウを変える。

▼Windowsキー + Arrowキー
画面を最大化したり最小化したり左半分に開いたり右半分に開いたり。

デュアルモニタでウィンドウを移動させたい時もコイツ。Shiftまぜて遊んでもいいよ。

▼Alt + F4
ウィンドウを閉じる。

▼Shift + F10
コンテキストメニューを開く。つまり右クリック的な。

キーボード生活に慣れてくると必須テクになってくる。

▼Windowsキー + Shift + S
画面キャプチャ。
ドラッグドロップで範囲選択してクリックで確定。マウスアレルギーの人はShift + Arrowキーで範囲選択を開始できる。

Snipping ToolでもCtrl + NからShift + Arrowで範囲選択できるよ。

新しめOSバージョンなら「切り取り領域とスケッチ」っていう吐くほど便利なキャプチャツールが起動するらしい。俺も使いたい。フォーカスが選択肢に当たっちゃってるときはTabで離脱してから範囲選択しろ。

切った画像は自動でクリップボードにぶち込まれるが、たとえば蛍光ペンで塗ったりお絵かきしたい時は通知をクリックして泣きながらマウスで線引け。

Arrowでカーソル動かすのが辛い人は是非もなくThinkPad X1 Carbonを買って乳首をいじろう。めっちゃ相性良いぞ。

▼Windowsキー + L
画面ロック

▼Windowsキー + T
タスクバーにフォーカスできる。アローキーで移動し、アプリケーションキーでコンテキストメニューを開ける。Shift + F10で開けないのはバグだろうか。

「最近使ったワークスペース」にすぐアクセスしたい時に便利。

▼ファイルエクスプローラー
Windowsキー + Eで起動してもいいよ。

★必修科目

Alt + 上Arrowで親フォルダに移動できる
Ctrl + Shift + Nで新しいフォルダ生える
名前変えキーの称号を欲しいままにしているF2
▼みゃあ…さっきまでそのファイル開いてたんだけど閉じちゃった…ふぇぇ…
Windowsキー + Tab　⇒　下Arrowキー

追記：OSバージョン古いと「アクティビティの履歴」が残らんかもしれない。不便。あと「プライバシーの設定」から「アクティビティの履歴」の「～収集する」をオフにしてたら記録残らないゆえ、使えないですよ。

▼シャットダウンしたいとき
Windowsキー + XしてArrowキーで操作。

・コンテキストメニュー。Shift + F10。
・ウィンドウ閉じる。Alt + F4。
・Alt + Spaceからウィンドウの移動ができるが、遅すぎて使えない。


```

##### mac
Mac OS-X : adobe系のショートカットで困るので、キーバインドはいじらず、そのままにする。

+ cp (photoshopと同じ)
option + drag-and-drop

+ Finderを開いた状態で cmd + shift + G を押すとダイレクトに移動先のパスを入力することができます。

+ mv
command + drag-and-drop

+ alias
command + option + drag-and-drop

+ Command + Option + Esc  => アプリを強制終了する専用のダイアログを表示。

+ fullScreen: command + ctrl + f
+ command + H: 隠す。
+ Fn + `F11` (HHKBだと Fn + -): sideBar として折りたたむ。
+ command + 2: リスト表示
+ option + アコーディオンを開く: 下の階層のディレクトリも開いた状態で表示
+ ctrl + タイトルバーをクリック: 任意の上の階層へ移動

+ file_open: command + o
+ rename: enter
+ copy_filePath: 右クリック中にoption
+ command + shift + click: 複数選択

##### linux
  + ctrl + r: history


##### chrome
+ `F12`: develop
  + alt + command + i

+ controll-panel
  command + option + i

+ capture full-screen
  command + shift + p
  => "full..."

```
  デフォルトでは、Googleの検索結果を開くのにTabキーをガシュガシュ連打しなければならない。Google検索キーボードショートカットを入れる。
  ▼Ctrl + L
  アドレスバーへのショートカット

  ▼Ctrl + T
  新しいタブを開く。
  Shiftを混ぜると「閉じたタブを開く」できる。閉じたウィンドウも復活できる。

  ▼Ctrl + Enter
  リンクを新しいタブで開く

  ▼Ctrl + Shift + V
  プレーンテキスト貼り付け

  ▼Alt + 左右Arrow
  戻る/進む

  ▼Ctrl + J
  ダウンロード履歴。わりと便利。
```

##### chrome


##### terminal
  + command + 2 :  タブ切り替え
  + ctrl + R : 履歴の後方検索
  + history | grep hoge

+ teraterm
  + alt + C, V, R(ペーストと改行)
  + alt + D （セッションの複製）
  + alt + I （切断）




___
###### vim
+ normal-mode
  + `shift + ~`  
    => upper-caseになる謎現象。

+ 範囲指定 => 置換
  + `ctrl + v` => `:` => `s/hoge/fuga/gc`

+ 範囲指定indent
  + `shift + v` => 5G => `>`


___
##### Editor
+ pycharm
  + shift + shift : search

+ atom
  + goto_definition
    + Alt+Cmd+Enter
  + command + shift + p : コマンドパレット

  + command + shift + o : プロジェクトを開く



##### eclipse
ショートカット
ctl + shift + f: formatter
ctl + shift + o: import文の編成
ctl + space: 補完（クラス直下でメソッド名だけを書いてから、作成変数名を途中までタイプしてから）
ctl + h: 機能検索

ctl + shift + s: すべてを保存
ctl + d: 一行削除
(矩形選択のことは忘れろ)
ctl + shift + / : 選択範囲をコメントアウト
alt + shift + r: まとめて名前変更
alt + shift + c: メソッドのシグネチャ変更

ctl + home(fn + left): 先頭移動
home(fn + left): 行頭移動
ctl + right: 次の単語へ移動

ctl + 1 : errorへの対応
ctl + . : errorにジャンプ

ctl + shift + w: すべて閉じる
ctr + e: ファイルの切り替え
ctl + alt + h: 呼び出し階層を開く
ctr + m: ビュー(ターミナル)の最大化・最小化

___
##### VS-code
+ ショートカット
crl + shift + space: パラメータヒントの表示
ctl + shift + h: 一括置換

ctl + z: 変更を戻す
ctl + shift + 方向: 矩形選択(解除esc)
ctl + shift + k: 一行削除

ctl + home(fn + left): 先頭移動
home(fn + left): 行頭移動
ctl + right: 次の単語へ移動
alt + 左右矢印: 過去の作業箇所に移動

ctl + shft + w: 閉じる
ctl + k → crl + w: まとめて閉じる
ctl + @: ターミナルの展開
ctl + shift + p (> user): コマンドパレット -> ユーザ設定
  ___
  ```
    {
      "key": "ctrl+shift+u",
      "command": "editor.action.transformToLowercase"
    },
    {
      "key": "ctrl+u",
      "command": "editor.action.transformToUppercase"
    },
    // VS-codeのターミナルのトグルが競合してうまくいかないので
    { "key": "ctrl+alt+`",
      "command": "workbench.action.terminal.toggleTerminal" },

    // // プロジェクト全体検索の切り替え
    // {
    //     "key": "ctrl+f",
    //     "command": "workbench.action.findInFiles",
    //     "when": "!searchInputBoxFocus"
    // },
    // {
    //     "key": "ctrl+f",
    //     "command": "workbench.action.focusFirstEditorGroup",
    //     "when": "searchInputBoxFocus"
    // },
    // // サイドバーのカーソル切り替え
    // {
    //     "key": "ctrl+j",
    //     "command": "workbench.action.focusSideBar",
    //     "when": "editorFocus"
    // },
    // {
    //     "key": "ctrl+j",
    //     "command": "workbench.action.focusFirstEditorGroup",
    //     "when": "!editorFocus"
    // },
    // // 左右にファイルを開いた時の切り替え
    // {
    //     "key": "ctrl+w ctrl+l",
    //     "command": "workbench.action.focusFirstEditorGroup",
    //     "when": "!editorFocus"
    // },
    // {
    //     "key": "ctrl+w ctrl+h",
    //     "command": "workbench.action.focusPreviousGroup",
    //     "when": "editorFocus"
    // },
    // // タブの切り替え
    // {
    //     "key": "ctrl+h",
    //     "command": "workbench.action.previousEditor",
    //     "when": "editorFocus && vim.mode == 'Normal'"
    // },
    // {
    //     "key": "ctrl+l",
    //     "command": "workbench.action.nextEditor",
    //     "when": "editorFocus && vim.mode == 'Normal'"
    // },
    // // Insert Modeでのカーソル移動
    // {
    //     "key": "ctrl+l",
    //     "command": "cursorRight",
    //     "when": "editorTextFocus && !editorReadOnly && vim.mode != 'Normal'"
    // },
    // {
    //     "key": "ctrl+h",
    //     "command": "cursorLeft",
    //     "when": "editorTextFocus && !editorReadOnly && vim.mode != 'Normal'"
    // },
    // // Suggestion時
    // {
    //     "key": "ctrl+k",
    //     "command": "acceptSelectedSuggestion"
    // },
    // {
    //     "key": "ctrl+n",
    //     "command": "selectNextSuggestion",
    //     "when": "editorTextFocus && suggestWidgetMultipleSuggestions && suggestWidgetVisible"
    // },
    // {
    //     "key": "ctrl+p",
    //     "command": "selectPrevSuggestion",
    //     "when": "editorTextFocus && suggestWidgetMultipleSuggestions && suggestWidgetVisible"
    // },
    // // 検索からファイルに移動する時
    // {
    //     "key": "ctrl+n",
    //     "command": "search.focus.nextInputBox",
    //     "when": "inputBoxFocus && searchViewletVisible"
    // },
    // // 検索窓を閉じる
    // {
    //     "key": "ctrl+[",
    //     "command": "workbench.action.closeQuickOpen",
    //     "when": "inQuickOpen"
    // },
    // // サイドバーでソースツリーを開いている時
    // {
    //     "key": "r",
    //     "command": "renameFile",
    //     "when": "explorerViewletVisible && filesExplorerFocus"
    // },
    // {
    //     "key": "Enter",
    //     "command": "list.select",
    //     "when": "explorerViewletVisible && filesExplorerFocus"
    // },
    // // どこにフォーカスしていても使いたいコマンド。
    // {
    //     "key": "ctrl+o ctrl+d",
    //     "command": "workbench.view.debug"
    // },
    // {
    //     "key": "ctrl+o d",
    //     "command": "workbench.view.debug"
    // },
    // {
    //     "key": "ctrl+o ctrl+g",
    //     "command": "workbench.view.scm"
    // },
    // {
    //     "key": "ctrl+o g",
    //     "command": "workbench.view.scm"
    // },
    // // サイドバーの表示切り替え
    // {
    //     "key": "[IntlYen] v",
    //     "command": "workbench.view.explorer",
    //     "when": "!explorerViewletVisible && vim.mode != 'SearchInProgressMode'"
    // },
    // {
    //     "key": "[IntlYen] v",
    //     "command": "workbench.action.toggleSidebarVisibility",
    //     "when": "explorerViewletVisible && !searchViewletVisible && !inDebugMode && vim.mode != 'SearchInProgressMode'"
    // },
    // // コマンドパレットオープン
    // {
    //     "key": "ctrl+o ctrl+o",
    //     "command": "workbench.action.showCommands"
    // },
    // {
    //     "key": "ctrl+o o",
    //     "command": "workbench.action.showCommands"
    // },
    // // エディター以外のビューから抜けてくるときに
    // {
    //     "key": "ctrl+w",
    //     "command": "workbench.action.focusActiveEditorGroup"
    // },
    // // Emmentをtabで展開
    // {
    //     "key": "tab",
    //     "command": "editor.emmet.action.expandAbbreviation",
    //     "when": "config.emmet.triggerExpansionOnTab && editorTextFocus && !editorReadonly && !editorTabMovesFocus"
    // },
    // // ターミナル切り替え
    // {
    //     "key": "ctrl+k",
    //     "command": "workbench.action.terminal.toggleTerminal",
    //     "when": "!terminalFocus && vim.mode != 'SearchInProgressMode'"
    // },
    // {
    //     "key": "ctrl+k",
    //     "command": "workbench.action.terminal.toggleTerminal",
    //     "when": "terminalFocus && vim.mode != 'SearchInProgressMode'"
    // }
  ]

  ```


##### VS Codeのカスタマイズ
  ```
  ▼アウトライン
  Ctrl + Shift + Eで開けるエクスプローラーは、下に「アウトライン」というメニューを持っている。これをエクスパンドすると、コード上の要素が一覧で表示される。パッと使えるとまぁまぁ便利。

  キーボードショートカットは設定されていないんで、Ctrl + Shift + Pでコマンドパレットを開いて「shortcut」とかタイプして設定を開いたら、「outline」と検索してfocusを好きなように登録しろ。俺は「Ctrl + NumPad_Decimal」に登録した。

  ▼何と呼べばいいかわからん機能
  「Ctrl + Pからのファイル名入力でそれを開けますわいな」って話をしたんだけど、ファイル名のあの…アレでもファイル名を開ける。

  つまり、「TacticalDeadlyNuclear.mp666」っていうファイル名があったとき、「tdn」と入力すればPON!とキマイラファイル名が出てくる。スネークケースでもキャメルケースでもいけちゃう。

  ファイル名に限らず、変数名だのもそうやって呼び出せるぜ。Shiftキー押さなくていいぜ。

  これ便利なんだけど、やっぱり名前がわからん。誰かすかへでけねべが。

  ▼ファイル開く
  「規定のプログラムで開く」ができない。する手順。

  VS Codeのエクスプローラーでファイルを選択。
  あるいはEnterを押してエディタを開く。
  Shift + Alt + Rしたらエクスプローラー開くから、Enterする。
  あるいは「Ctrl + Shift + P」からの「reveal」で。
  エクスプローラーがポコポコ開くのが辛い。誰か助けて。




  VS Codeのショートカットをカスタマイズした。

  Ctrl + Shift + Pでアレを開いて「shortcut」とか入力して「キーボード ショートカットを開く」を選択していい感じにしろ。

  俺が設定しているのは

  Ctrl + numpad0でテキスト整形
  （Format Document）
  Ctrl + numpad1で最初の分割に移動
  （Focus First Editor Group）
  Ctrl + numpad2で二個目の分割に移動
  （Focus Second Editor Group）
  だ。numpadはテンキーのことです。あるとやっぱり便利。

  あと、HomeとEndが押しづらいキーボードあんじゃん？そういう時は「Ctrl + Alt + 左右Arrow」を「cursorHome」「cursorEnd」に割り当ててしまってもいいかなと思う。というのも、Ctrl + Alt + 左右Arrowがもともと使ってた「タブを分割に移動」はCtrl + Alt + PageUpDownに割り振った方が分かりやすいと思うんだよね。だから、そんな感じ。

  それほどにHomeとEndは便利なんですよ。信者にあまり会わないけど。


  ___

  ◆エディタ自体の操作
  ▼Alt
  分かってると思うけど、ツールバーにアクセスできる。単純かつ強力だけど意外と忘れがち。

  ▼Ctrl + P
  ほんとこれ。キーボードから手を放す時間を極力減らしたい人はこれ。

  Ctrl + Pを入力することによりコマンドパレットが開く。そこにファイル名を入力し、選んでEnterを押せ。開くから。離脱はEscapeキー。

  ファイル名を忘却したときはCtrl + Shift + Eでファイルエクスプローラーを召喚しろ。あるいは「Ctrl + Qポチポチ」でもエクスプローラーを開ける。

  開いたファイルの名前がイタリックで表記されていたらプレビューモードだから、開きっぱなしにしたかったらCtrl + K からのEnterでプレビューモード解除しろ。

  ▼Ctrl + Shift + P
  さっきの「コマンドパレット」に「>」が入力された状態で開かれる。でね？たとえば「>case」と入力すると「小文字に変換」とか「大文字に変換」とか表示されますね？そいつにフォーカスしてEnterを押せば、選択範囲の英字が大文字小文字変換されるんですね！すごいですね！拙者興奮してきました！

  これは後で紹介する「マルチカーソル」と一緒に使えばえらいことになる。

  また、拡張機能を呼び出すときも主にCtrl + Shift + Pからですね。「>git」と入力すればGitのコマンドも大体使える。クッソ便利。

  あと、エラー行にホバーするとその原因が表示されるじゃん？それはCtrl + KからのCtrl + Iで表示できるらしいんだが、なぜか効かないからコマンドパレットで「>hover」と入力して表示をしている。⇒追記：なんか近頃きくようになってきたから便利。

  ▼Ctrl + B
  これ。ほんとこれ。これすぎる。

  サイドバーの開閉をすることが出来る。

  ▼Ctrl + PageUpDown
  タブからタブへ移動できる。Ctrl + Shift + PageUpDownでタブを掴んで移動させることもできる。

  ▼Ctrl + Tab
  開いているタブから選んで移動できる。Shiftまぜれば逆順に移動。PageUpDownの価値がまた一つ無くなってしまった。

  Ctrl + Tabを一度押せば、一個前に開いていたファイルに戻ることが出来る。超重要。

  ▼Ctrl + W
  タブを閉じる。たまに叫びながら連打して全部のタブを閉じるのもをかし。

  いとをかしなんだけど、全とじはCtrl + KからのCtrl +Wなりたるに、ほのかにCtrl + Shift + W押したるやウィンドウごと閉じやがりてわろし。

  ▼Ctrl + \
  これだ！（驚愕）

  エディタを左右に分割することが出来る。一つの長いファイルは左右に開いて編集すると便利だね。
  ただ、こいつを使いこなすためにはCtrl + Alt + 左右Arrowを知らなければならない。Ctrl + Altを押しながら左右キーを押すと、開いているタブを分割域（？）に移動させることが出来る。

  ▼Ctrl + 1
  エディタが分割されているとき、最初の分割にフォーカスする。Ctrl + 2で二個目の分割にフォーカスする。

  割と重要テクです。とにかくエディタに戻りたい時はコイツを使う。

  ▼Ctrl + @
  ターミナルさんを開く。フロントエンド開発だと超重要ですね。それ以外でも使いこなせればクッソ便利だ。
  node_modulesを葬るコマンドは「rm -r node_modules」です。

  Ctrl + Shift + @で新しいターミナルさんを召喚することも可能。閉じたい時はもう一回Ctrl + @を押せばよい。つまりCtrl + @の二回押しで下の枠を閉じる。

  ___
  言語モード変更
  ▼Ctrl + CとかCtrl + VとかCtrl + XとかCtrl +AとかCtrl + ZとかCtrl + YとかCtrl + Sとか
  知ってるだろ。


  適当にカーソルを置いた状態でCtrl + Cを押すと「その行」がコピーされる。Ctrl + Vを押すと行が張り付けされる。Ctrl + Xで一行切り取ることができる。意外と知らない人が多くてもっこりした。

  あと、新しめのOSバージョン使ってる人はぜひともWindowsキー + Vを使おう。クリップボードの履歴を参照できる。できないならWindowsキー押して「クリップボード設定」を開け。

  ついでに、改めて説明すんのもアレだけどF7でカタカナ、F8で半角ｶﾅ、F10は半角英数字だからな。強者は「ぷｂぃｃ」とか全角で入力しちゃったときにCtrl + Spaceで半角スペースを挿しつつ最後にF10で大逆転する。

  もっというと、変換中にShift + Spaceで逆順だぞ。あと全角半角切り替えはCapsLockキーでもできる。このあたりの初級忍術くらいは知っとけ。

  ▼Home/End
  行頭、行末にカーソルを移動させることが出来る。強力。でもみんな忘れがち。
  Shiftを一緒に押すとテキストの選択をすることができる。

  つまり、Home ⇒ Shift + Endで行頭から行末まで選択することが出来る。

  ▼Ctrl + 左右Arrow
  カーソルを単語単位で動かすことが出来る。こいつもShiftを一緒に押すとテキストの選択をすることができる。

  ▼Ctrl + Alt + 上下Arrow
  上下にカーソルが伸びる。伸びるっていうのは、カーソルが増えるってことだ。これは…クッソつよい。

  ひとつじゃなくてマルチにカーソルが配置されるので、「マルチカーソル」と呼ばれている。複数の位置にカーソルがある時に文字を打つとそりゃあ全部のカーソルで文字が入力される。すごい。

  Escapeキーでマルチカーソルモードから離脱できる。

  マルチカーソル中にEndキーを押すと、複数行の行末にまとめてカーソルを当てることができる。また、マルチカーソルでCtrl + 左右Arrowもできる。ヤバすぎ。

  change-caseって拡張機能を入れると複数選択状態でsnake_caseやらPascalCaseやらcamelCaseやらを行き来することもできる！もうExcelとサクラエディタ立ち上げなくていいんじゃよ！

  ▼Ctrl + Shift + Alt + Arrow
  Ctrl + Shift + Altをおしっぱにしながらアローキーを上下左右に押すことにより、テキストを矩形選択することができる。これは使わないわ。でも楽しいから教えておく。

  ▼Shift + Alt + I
  選択している複数行について、末尾にカーソルを（マルチに）置く。
  基本的にEndキーでなんとかなるけど、大量データを扱いたい時に使うだろう。

  大量データを作る時は

  「Ctrl + G」で行番号使って行にジャンプ
  「Ctrl + Shift + End」で末尾まで全選択
  Shift + Alt + Iでマルチカーソルにする
  Homeキーで行頭に飛ぶ
  「vscode-input-sequence（バグってる）」拡張機能で連番を入力
  を覚えておけばよかろう。

  破廉恥にもマウスの話をさせていただくが、カーソルを適当に置いた後でどっか他の行を「Shift + Click」をすると、そこまでが選択される。これで大量の行を選択できますわな。

  ▼テキスト選択しながらCtrl + D
  選択している文字列と同じ文字列を次々とマルチカーソル状態で選択していく。選択された状態で文字を打つと当然ながら置き換えられる。

  マウス操作に辟易しているあなたには申し訳ないが、テキストをダブルクリックすると単語を選択することができる。常識なようで意外と気づいてない人がいるんだなこれが。

  ▼Alt + Click
  ポチポチとクリックすると、クリックした位置にカーソルが置かれる。複数置くことができる。メニューバーの「選択」から「マルチカーソルを～切り替える」を見つけてクリックすると、Ctrl + Clickで同じことが出来るようになる。なんかかわいいだけで使い時がイマイチわからん機能を紹介してしまった。大概Ctrl +Dでなんとかなる。やっぱマウスって糞だわ。

  ▼Shift + Alt + 上下Arrow
  行を上下にコピーできる。Alt + 上下Arrowで、行を掴んで移動できる。

  複数行でもコピれる。移動できる。すごい。

  ▼Ctrl + L
  行を選択できることは知っていたんだが、連打するとどんどん下の行を選択できることに気づいた。これすげぇ。知ってしまったらもはや必須レベルだ。

  Lとかクッソ押しやすいし、☝の行コピーとかめっちゃ簡単になるじゃん。行頭から選択できるのも素晴らしい。いままでShift + 上下Arrow押していたのが大分楽になるな。

  ▼Ctrl + F
  大体わかってるだろうけど・・・テキスト検索ですね。死ぬほど使え。検索機能ではなく移動機能だと思え。

  テキスト置換はCtrl + H。Ctrl + Hをもう一回押すと、置換後テキストの入力にフォーカスできる。Tabキーでもカーソル移動できるね。

  Alt + Rで正規表現（Regex）モードで、Ctrl + Alt + Enterで全置換え。

  Escapeで終了するとハイライトが消えちゃうから、Ctrl + 1とかCtrl + 2でエディターにフォーカスを移せ。

  GrepはCtrl + Shift + Fです。

  ▼Shift + Alt + F
  テキスト整形。利用頻度からしたらクソ押しづらい。

  「あんたはん、保存時に自動整形しておくれやす」って京都人はコマンドパレットで「>setting」と入力して「基本設定：ユーザー設定を開く」を選択したら基本設定が開くから、「format on save」と入力しなさい。そしてTabキーをガチャガチャ押して「Editor: Format On Save」のチェックボックスにフォーカスしてEnterキーを押しちゃいなよ。そしてCtrl + Wでタブを閉じちゃいなよ。俺が許可するよ。

  ▼Ctrl + Del
  行末でDelキー押すと、当然ながらインデント付いてくるじゃん？でもCtrlを一緒に押すとインデントまで消してくれる。
  「消えたらいいなぁ」と思って試したら消えた。しゅごい。

  「Delete Word Right」という機能だらしい。カーソルの右にある単語を消してくれるそうな。でも「Ctrl + Shift + →」からのBackspaceに慣れ親しみすぎてどうも。そいで、行末で使ったときは改行文字と空白系文字を一緒にけしてくれるよと。それは便利ね。

  ▼F12
  変数やらを定義している場所に飛ぶ。Alt + Clickでもいけるよ。

  Alt + F12で、定義を子ウィンドウに表示することが出来る。便利。そこからShift +Tabを押すと子ウィンドウ内で操作ができるよ。終わったらEscapeで離脱。

  ▼Ctrl + Space
  インテリセンス。…なに？ドット消しぃのドット打ち直しぃのでインテリセンスを呼んでいるだと？いけない子だ（暗黒微笑）

  あとはまぁCtrl + . でクイックフィックスだらしいんだけど、VS Codeで使ったことないっす。ふつうのVisual StudioでC#の開発してるとクイックフィックス（クイックアクション）はかなり重要なコマンドで、エラーの赤ニョロが出てる部分にカーソルを当ててCtrl + . を入力すると「こんな感じに直せばええんちゃう？」とか「このクラスのインターフェース生成したろか？」とか卑猥な提案をしてくる。

  「Ctrl + Space」と「Ctrl + K からの Ctrl + I」と「Ctrl + .」は、その赤ニョロバスター的便利さからラーメン三銃士と呼ばれている（意味不明）

  ▼Ctrl + Shift + \
  対応するカッコに飛ぶ。クソでかJSONくんをいぢる時に便利。

  Bracket Pair Colorizer拡張機能を入れれば、対応するカッコがいい感じにビジュアライズです。

  ▼Ctrl + K からの Ctrl + C
  コメントアウト。Ctrl + K からの Ctrl + U でアンコメント。

  ▼Ctrl + /
  コメントアウト、アンコメント。当然ながら複数行でもいけるよ。

  だとしたらCtrl K Cは別のショートカットに使えるな。や、逆にCtrl + /に違うショートカットを当てるって説もある。が、ほかの人のエディタとあんまり設定変えると混乱するからやりたくねぇなぁ。


  ```

