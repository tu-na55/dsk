文字コード変換に nkf, 形態素解析に mecab, グラフ作成に plot を利用しているので、それらのインストールコマンドも置いておきます。また、nkf と mecab のインストールには Homebrew を使っています。

```bash
# nkf, mecab, plot のインストール
$ brew install nkf
$ brew install mecab
$ brew install mecab-ipadic

$ go get gonum.org/v1/plot/
```

あと、青空文庫から文章ファイルをダウンロードしてグラフを作成するシェルスクリプト。
第1引数に文章ファイルの URL を指定して使います。たとえば、夏目漱石の 吾輩は猫である なら https://www.aozora.gr.jp/cards/000148/files/789_ruby_5639.zip を第1引数に指定します。

やっていることは非常にシンプルですが、青空文庫で公開されている文章はルビがふられているので、除去しています。


```bash
#!/bin/sh
URL=$1
ZIPFILE=`basename ${URL}`

echo "PROCESS: ${URL}"

# zip のダウンロード
curl --output ${ZIPFILE} ${URL}

# zip の展開
FILE=`unzip ${ZIPFILE} 2>&1 | egrep '.txt' | awk '{print $2}'`
rm ${ZIPFILE}

# 文字コードを Shift_JIS から UTF8 へ
nkf -Sw80 --in-place ${FILE}

# ルビを除去
sed -i -e 's/《[^》]*》//g' ${FILE}
rm ${FILE}-e

# 形態素解析
MECABFILE=${FILE}.mecab
# 1行がかなり大きいファイルがあるのでバッファサイズを多くとる
cat ${FILE} | mecab -b 32768 > ${MECABFILE}
rm ${FILE}

# グラフを作る
./zipf ${MECABFILE}
rm ${MECABFILE}
```

グラフを作る Go 言語のプログラム (シェルスクリプトの一番下の方で使っている zipf というコマンド)
いずれも、簡潔にするためにエラー処理はほとんど書いていません。
```go
package main

import (
	"bufio"
	"os"
	"strings"
	"sort"
	"math"
	"gonum.org/v1/plot"
	"gonum.org/v1/plot/plotter"
	"gonum.org/v1/plot/plotutil"
	"gonum.org/v1/plot/vg"
)

func main() {
	var input string
	if len(os.Args) <= 1 {
		return
	} else {
		input = os.Args[1]
	}

	// 単語をカウント
	counts := countWords(input)

	// グラフを作る
	p, err := plot.New()
	if err != nil {
		panic(err)
	}
	p.Title.Text = input

	if err := plotutil.AddScatters(p, point(counts)); err != nil {
		panic(err)
	}

	// グラフを画像ファイルに保存
	output := input[0:strings.Index(input, ".")] + ".png"
	if err := p.Save(5*vg.Inch, 5*vg.Inch, output); err != nil {
		panic(err)
	}
}

func countWords(path string) []int {
	f, err := os.Open(path)
	if err != nil {
		panic(err)
	}
	defer f.Close()

	// 単語をカウント
	m := make(map[string]int)
	scanner := bufio.NewScanner(f)
	for scanner.Scan() {
		line := scanner.Text()
		if strings.Index(line, "EOS") != -1 || strings.Index(line, "\r") != -1 {
			continue
		}

		word := strings.Split(line, "\t")[0]
		m[word] = m[word] + 1
	}

	// ソートするためにスライスへ
	var counts = make(sort.IntSlice, len(m))
	i := 0
	for _, v := range m {
		counts[i] = v
		i++
	}

	// 出現頻度でソート
	sort.Sort(sort.Reverse(counts))
	return counts
}

func point(counts []int) plotter.XYs {
	pts := make(plotter.XYs, len(counts))
	for i, v := range counts {
		pts[i].X = math.Log10(float64(i + 1))
		pts[i].Y = math.Log10(float64(v))
	}

	return pts
}
```

