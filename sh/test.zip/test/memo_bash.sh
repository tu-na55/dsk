#!/bin/bash
set -euC

# 下記のコマンドを~/.bashrcに記述しておけば設定を永続化出来ます。
# 大文字小文字を区別する設定 Insensitive
# shopt -u nocasematch
###########################################
command > `date +%Y%m%d_%H-%M-%S`.log

###########################################

# tree

# 相対パス
# tree -f -N
# -N 文字化け防止
# tree -L 2 -N
# 指定ファイル パターンマッチしなくてもディレクトリは表示される
# tree -P 'test1_1N.txt'
# 親dirまで
# tree -d 'test1_1N.txt'





# $ pwd
# ~/OneDrive/デスクトップ/sh_ppmLog-to-csv
###########################################
# basename $path
# var="/my/path/dir/test.dat.org"
# echo ${var##*/}
# echo ${var%%.*}

###########################################
# 外部ファイルを読ませる
# while read line
# do
#   echo $line
# done < file.txt
###########################################


# for file in *est[0-9]_1N.txt; do
#   if [ ! -e "$file" ]; then continue; fi
#     echo $file
# done

###########################################
# if [ ! -f /var/log/egawa/egawa.log ]; then
#   echo "file not found"
# else
#   :
# fi

###########################################

# ~/OneDrive/デスクトップ/sample_sh/result/1911/controller
# find ./ -name '*' | xargs grep '生産性'

# grep: ./: Is a directory
# grep: ./theme_ppm: Is a directory
# grep: ./theme_ppm/result: Is a directory
# grep: ./theme_ppm/result/1911: Is a directory
# grep: ./theme_ppm/result/1911/controller: Is a directory
# ./theme_ppm/result/1911/controller/test1_1N.txt:生産性測定結果

##################
# 例えばパスからディレクトリの配列を得るにはこうなる。
# split（というか置換してるだけ）の処理は一行。便利！

# split-sub.sh
#!/bin/bash
# path=$1;
# declare -a a_dirs=();
# a_dirs=${path//\// };

# for dir in ${a_dirs[@]};
# do
#   echo $dir;
# done

# exit 0;

# 実行結果
# $ ./split-sub.sh $(pwd)
# Users
# tommarute
# script
# split_test
##################


# for val in 'find ./*';
# do cat $val > $val.txt;
# done




# ファイルパスリスト
# find . -name 'test1_1N.txt'
# find . -name *est[0-9]_1N.txt
# ./test5_1N.txt
# ./test6_1N.txt
# ./theme_ppm/result/1911/controller/test1_1N.txt


###########################################
# インデックスに @ を指定して、全ての要素を for 文の値リストに指定
# files=(`ls -1`)
# for file in ${files[@]}
# do
#   # 各ファイルのファイルサイズを取得
#   size=`ls -l $file | awk '{print $5}'`

#   echo "FILE: $file - $size byte"
# done
# exit 0



###########################################


##################
# min, maxの抽出 #
##################
# timesjdg 4530 4600
range=`grep 'timesjdg' <(strings $data)`

jdg_min=4530
jdg_max=4600
# echo $l
# echo $g

# min=`echo ${l} | sed -e 's/^[0-9][0\\-9]/./'`
min=45.30
max=46.00

# echo $min

# l=`echo ${min} | tr -d '.'`
# g=`echo ${max} | tr -d '.'`

###########################################
# 切り出し２
# 右から文字数ぶんを抽出
# echo $range | rev | cut -c 6-9 | rev
# echo $range | rev | cut -c 1-4 | rev
###########################################
# 切り出し３
# echo $range | awk '{print substr($0,10,length($0))}'
# 4530 4600
###########################################


###########################################
# function compare(){}
###########################################



# $ find . -name "*.log" -exec rm -fv {} \;
# './access.log' を削除しました
# './error.log' を削除しました

# $ find . -name "*.log" | xargs rm -fv
# './access.log' を削除しました
# './error.log' を削除しました

# 自分はこのワンライナーで初めて xargs コマンドに触れました。

# そして、これなら rm *.log だけで良くない？xargs コマンドを使うメリットってどこにあるの？って混乱したのを覚えています。

# 確かに、このワンライナーと実行結果を見ると rm コマンド単体で問題ありません。

# しかし、find コマンドは名前検索以外にも様々な条件でファイルを検索することが出来るので、xargs コマンドと組み合わせると作業効率の幅が広がります。

# タイムスタンプで検索できる
# パーミッションで検索できる
# ファイルサイズで検索できる（空ファイルも検索できる）
# 検索する階層を指定できる
# ネットで検索した xargs コマンドのサンプルには、このようにメリットが感じられないサンプルも多々あります。


###########################################
# ffmpegで動画から画像を切り出すときの連番に使おう。

# seqコマンドのオプションを再確認
# 　-w 頭ゼロ埋め
# 　seq 0 10 1000　0から1000までを10飛ばしで表示する
for i in $(seq -w 0 10 1000); do echo "$i"; done
###########################################
# パターンマッチ
# if の条件のなかに [[ ]] のダブルブラケットを書くのがポイントです。正規表現はクオテーションは不要です。クオートしたら動かないので注意してね。

tel='09012345678'

if [[ $tel =~ [0-9]{3}-?[0-9]{4}-?[0-9]{4} ]] ;
then
  echo match
fi
###########################################
# 正規表現のORを使う例
function match_test(){
  printf "%-18s: " "$1"
  if [[  $1 =~ apple|pen   ]];  then
    echo match
  else
    echo dose not match
  fi
}
match_test "Hello world."
match_test "This is a apple."
match_test "This is pen."
match_test "This is a boy."
###########################################
# 切り出し１bashのみ

# HOST=`uname -n`
# echo ${HOST}
# => dbserver1

# 変数に入れる文字列の文字数が決まっている場合
# サーバの種類を取得：dbserver
# ${HOST:0:8}
# 末尾のみ取得：１号機
# ${HOST: -1}

# 開始位置の指定
# 数字二桁のときの挙動が変
echo ${range:9:14}
###########################################
# 変数内文字列削除
testvar='bananafishbook'
echo ${testvar} | sed -e 's/book$//g'
# 簡易版：たぶんbashだけ
echo ${testvar%book}

#  "192.168.0.1" の部分を切り取って RETVAL 変数に
data="IP Address: 192.168.0.1/255.255.255.0"
RETVAL=`echo "$data" | sed -e "s/^IP Address:[ \t]\+\([0-9\.]\+\)\/[0-9\.]\+$/\1/g"`
# 先頭の 5 文字を取り除く
echo $data | awk '{print $3}' | sed -e "s/^.\{5\}//"
# 末尾の 3 文字を取り除く
echo "$data" | sed -e "s/.\{3\}$//"

値をコロンで分離して、それぞれを NAME 変数と VALUE 変数に格納するといったことも可能です。
NAME=`echo "$DATA1" | sed -e "s/^\([^:]*\):\(.*\)$/\1/"`
VALUE=`echo "$DATA1" | sed -e "s/^\([^:]*\):\(.*\)$/\2/"`

# 小数点のドットを抜く
# こっちはファイルでも使える
echo ${min} | sed -e 's/\.//g'
# 変数内ならこっちのほうが楽
min=11.00
echo ${min} | tr -d '.'

###########################################
##########
# まとめ #
##########
# length
  # lastNum=`expr ${#arr[@]} - 1`
  # testNum=`echo ${arr[$lastNum]} | `



# hash
  # declare -A hash3=()
  # hash3=([$i]=$val3)
  # for h3 in ${!hash3[@]} ;
  # do
  #   echo $h3
  #   echo ${hash3[$h3]}
  # done



# split()相当
# tr '区切り文字' '\n'

# 配列を結合して1つの文字列にする操作join()相当
# paste -s -d '区切り文字' -
###########################################
# 行ごとにarrayに格納
# data.txt<<EOS
# 1
# 2
# 3
# 4
# EOS

# $2, $3だけほしい場合だけには向かないかも
# data_list="data.txt"
# IFS=' '
# set -- $data_list
# echo $2
# echo $3
###########################################
# 区切り文字ごとにarrayに格納
data='0,1,2,3'

# カンマなしに置換してarrayに入れる
arr=(`echo $data | tr -s ',' ' '`)
echo ${arr[0]}

###########################################
# foreach
$ for item in "${array[@]}"; do echo "$item"; done | sort
###########################################
# 無駄が多い
declare -a inputFiles=(`find . -type f | grep -E "*[0-9].txt" | sort | tr '\n' ' '`)
echo ${inputFiles[@]}

# 変数をブレース展開して、lengthぶんfor文でまわす
num=`expr ${#inputFiles[@]} - 1`
len=`eval echo {0..$num}`
for i in $len ;
do
done


###########################################
# 先頭に追加
# array=(3 "${array[@]}")
# array は (3 “a” "b" "c")

# 末尾に追加
# array=("${array[@]}" 4)
 # array は (3 "a" "b" "c" 4)
# array+=( 5 )
 # array は (3 "a" "b" "c" 4 5)

#  配列のデータを参照する
# i=0
# for e in ${array[@]}; do
#     echo "array[$i] = ${e}"
#     let i++
# done

# Bash 独自の記述 1
# echo "${array[@]}"
# a b c

# ある要素を削除
# unset array[1]
# echo "${array[@]}"             # arrayは("a" "c")

# echo ${array[0]}               # array[0]は"a"
# echo ${array[1]}               # array[1]は ""（空）
# echo ${array[2]}               # array[2]は"c"
# 配列の中身のデータは削除できても、配列自体は削除できません。

# 添字を詰めたければ、
# array=("${array[@]}"
# 代入しなおす必要があります。

# unset array[@]                 # 全削除する
# echo "${array[@]}"             # 配列 array は ""（空）
# echo "${#array[@]}"            # 要素数は0



###########################################
# 計算するだけなら
# result=$(( num1 + num2 ))

# 小数点の計算はbcコマンドを使う


# インクリメントはexprだと遅すぎるので
count=$(( count + 1 ))
###########################################
# ランダム
foo=(apple banana orange)
INDEX_MAX=`expr ${#foo[@]} - 1`    #### 3 - 1

for i in `seq 0 1 $INDEX_MAX`
do
    echo "foo[${i}] : ${foo[$i]}"
done

###########################################
### read csv ###
# while read row; do
#   column1=`echo ${row} | cut -d , -f 1`
#   column2=`echo ${row} | cut -d , -f 2`
#   echo "${column1}の番号は${column2}です。"
# done < sample.csv

# $ ./sample.sh
# => nameの番号はnumberです。
# => name1の番号は0001です。
# => name2の番号は0002です。
# => name3の番号は0003です。




