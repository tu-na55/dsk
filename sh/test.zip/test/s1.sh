#!/bin/bash

# スイッチ
set -euC


# ___
# デバッグ
# set -x
# VAL1=hoge
# echo "Output: ${VAL1:-hoge}"


# ___
# 引数の上書き
# echo ORIGINAL ARGS: "$@"
# set -- word1 "some value"
# echo CHANGED ARGS: "$@"


# ___
# trap 'read -p "pause"' DEBUG
# trap caller ERR


# ___
# logの出力
# function log() {
#   local fname=${BASH_SOURCE[1]##*/}
#   echo -e "$(date '+%Y-%m-%d %H:%M:%S') ${fname}:${BASH_LINENO[0]}:${FUNCNAME[1]} $@"
# }

# log "message"



# ___
# 安全なファイル(rename)
# if [[ ! -e target_file.csv ]]; then
#   find ./hoge/ -name \*.txt >> target_file.csv.tmp
#   echo "special.txt" >> target_file.csv.tmp
#   mv target_file.csv.tmp target_file.csv
# fi


# ___
# array
declare -a array=("a" "b" "c")

echo "len:" ${#array[@]}
array=("x" "${array[@]}")
array=("${array[0]}" "d")

echo "___"
echo ${array[0]}
echo ${array[1]}
echo ${array[@]}

echo "___"
for v in "${array[@]}"
do
  echo $v
done





