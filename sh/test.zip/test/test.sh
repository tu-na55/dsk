#!/bin/bash

a=(10 20)
a[1]=10
a+=(20 30)

echo ${a[@]}
echo ${#a[@]} # len
echo "==="

# t = than
# e = eq
test ${a[1]} -ge 10; echo $? # >=
test ${a[1]} -lt 10; echo $? # <
echo "==="

# newer than, older than
test hoge.sh -nt temp_dict1.html; echo $?
test hoge.sh -ot temp_dict1.html; echo $?
echo "==="


# 省略記法ではスペースに注意
[ "a" = "a" ]; echo $?
# dirはファイルでないのでfalse
[ -f js ]; echo $?


if [ -w hoge.sh ]; then
  echo $?
  echo "w: ok"
fi
echo "==="


test 1 <> 2 -a 1 <> 0 ; echo $?
echo "==="

# and の方が優先されるので
test \( 1 = 1 -o 1 <> 1 \) -a 2 = 2 ; echo $?

( test 1 -eq 1 || test 1 -ne 1) && test 2 -eq 2 ; echo $?

( [ 1 = 1 ] || [ 1 <> 1] ) && [ 2 = 2 ] ; echo $?

echo "==="

# 反転
! true; echo $?
echo "==="


# if ls fuga.txt fuga_cp.txt > /dev/null 2>%&1; then

# 古い方の削除
#   if [ fuga.txt -ot fuga_cp.txt ]; then
#     echo "remove fuga.txt"
#     rm -f fuga.txt
#   else
#     echo "remove fuga_cp.txt"
#     rm -f fuga_cp.txt
#   fi
# else
#   echo "file not found..."
#   exit 1
# fi

# exit 0
echo "==="


# echo -n 'Input "a" or "b": '
# read KEY

# if [ "$KEY" = "" ]; then
#   echo "何も入力されませんでした"
# elif [ "$KEY" = "a" ]; then
#   echo '"a"が入力されました'
# elif [ "$KEY" = "b" ]; then
#   echo '"b"が入力されました'
# else "不正な値: $KEY"
# fi

# exit 0
echo "==="


if echo "$var" | grep -sq "hoge"; then
  echo "hogeが見つかりました"
fi
echo "==="

if echo "$var" | grep "hoge" > /dev/null 2>$1; then
  echo "hogeが見つかりました"
fi
echo "==="



# コマンドを実行して $? を判定する
echo "$var" | grep -sq "hoge"
if [ $? -eq 0 ]; then
  echo "hoge が見つかりました"
fi



# 終了ステータスを使いまわしたい場合、もしくはコマンドと条件式の間で別のコマンドを実行したい場合は、いったん変数に格納しておく。
# 任意の変数に終了ステータスを退避しておくことで、$? が他のコマンドによって上書きされても影響を受けないようにすることができる。
echo "$var" | grep -sq "hoge"; result=$?
echo "終了ステータスを変数に対比したので、間でコマンドを実行してもOKです" > /dev/null

if [ $result -eq 0 ]; then
  echo "hogeが見つかりました"
  echo "終了ステータスは$resultです"
fi






