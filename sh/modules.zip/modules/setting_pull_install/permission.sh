指定ディレクトリ配下のファイルのパーミッションを見る
$ find . -printf "%U %G %m %p\n"


# rootユーザでのみ実行を許可
user=`whoami`
if [ $user != "root" ]; then
    echo "you need to run it on the 'root' user." 1>&2
    exit 1
fi