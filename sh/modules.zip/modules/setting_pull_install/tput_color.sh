#!/bin/bash
set -euC

if [ "${TERM:-dumb}" != "dumb" ]; then
    txtunderline=$(tput sgr 0 1)     # Underline
    txtbold=$(tput bold)             # Bold
    txtred=$(tput setaf 1)           # red
    txtgreen=$(tput setaf 2)         # green
    txtyellow=$(tput setaf 3)        # yellow
    txtblue=$(tput setaf 4)          # blue
    txtreset=$(tput sgr0)            # Reset
else
    txtunderline=""
    txtbold=""
    txtred=""
    txtgreen=""
    txtyellow=""
    txtblue=$""
    txtreset=""
fi

# 使い方 (装飾後は${txtreset}で戻すようにして使う)
${txtred}this text is red${txtreset}


### NOTE ###
$ tput setaf 1 && echo 'HelloWorld'
# 色番号	色
# 0	黒
# 1	赤
# 2	緑
# 3	黄色
# 4	青
# 5	マゼンタ
# 6	シアン
# 7	白

$ tput setaf <色番号> #文字色を色番号にする
$ tput setab <色番号> #文字色を色番号にする
$ tput cup <y座標> <x座標> # 上からx行目左からy文字目にカーソル移動
$ tput bold #太字
$ tput clear # clearコマンドと同じ効果
$ tput sgr0 # 装飾解除
$ tput cols # ターミナルの横幅を文字数で出力
$ tput lines # ターミナルの縦幅を文字数で出力
$ tput civis # カーソル非表示
$ tput cnorm # カーソル表示

