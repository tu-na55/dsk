#!/bin/bash
set -euC

# export LANG=ja_JP.UTF-8


brew update
brew install nodebrew
nodebrew install-binary latest
# nodebrew install-binary stable

# Warning: Failed to create the file
# mkdir -p ~/.nodebrew/src

nodebrew list
nodebre use <ver>

# echo 'export PATH=$PATH:$HOME/.nodebrew/current/bin' >> ~/.bashrc
# => ~/.bash_profile
# if [ -f ~/.bashrc ]; then
#     . ~/.bashrc
# fi

# .bash_profile
echo 'export PATH=$HOME/.nodebrew/current/bin:$PATH' >> ~/.bash_profile

source .bash_profile


ファイル名を指定してファイルを保存する curl
$ curl -o foo.txt https://hoge.com/fuga.txt -o bar.txt https://piyo.com/hogera.txt

##########################################
brew install pyenv
echo 'export PYENV_ROOT="$HOME/.pyenv"' >> ~/.bash_profile
echo 'export PATH="$PYENV_ROOT/bin:$PATH"' >> ~/.bash_profile
echo 'eval "$(pyenv init -)"' >> ~/.bash_profile
source ~/.bash_profile
python2=$(pyenv install -l | grep -v '[a-zA-Z]' | grep -e '\s2\.?*' | tail -1)
python3=$(pyenv install -l | grep -v '[a-zA-Z]' | grep -e '\s2\.?*' | tail -1)
pyenv install $python2
pyenv install $python3
pyenv global $python2 $python3
pyenv rehash

##########################################
$ pyenv_install() {
  # skip installation when pyenv is already installed.
  if [ `pyenv --version > /dev/null 2>&1; echo $?` == 0 ]; then
    echo '.pyenv is already installed.(skipping...)'
    return
  fi

  # pyenv
  git clone https://github.com/__name/pyenv.git ~/.pyenv;
  echo 'export PYENV_ROOT="$HOME/.pyenv"' >> ~/.bash_profile;
  echo 'export PATH="$PYENV_ROOT/bin:$PATH"' >> ~/.bash_profile;
  echo 'eval "$(pyenv init -)"' >> ~/.bash_profile;

  # pyenv-virtualenv
  git clone https://github.com/__name/pyenv-virtualenv.git ~/.pyenv/plugins/pyenv-virtualenv;
  echo 'eval "$(pyenv virtualenv-init -)"' >> ~/.bash_profile;

  source ~/.bash_profile;
}

$ pyenv_install


##########################################
# 以下コマンドで今インストールしたzshを追加する
$ sudo sh -c "echo '/usr/local/bin/zsh' >> /etc/shells"




