if type __git_ps1 > /dev/null 2>&1 ; then
  GIT_PS1_SHOWDIRTYSTATE=true
  GIT_PS1_SHOWSTASHSTATE=true
  GIT_PS1_SHOWUNTRACKEDFILES=true
  GIT_PS1_SHOWUPSTREAM="auto"
  GIT_PS1_SHOWCOLORHINTS=true
  PROMPT_COMMAND='\
    __git_ps1 \
    "\[\e[1;32m\]\u@\h\[\e[m\]:\[\e[1;34m\]\W\[\e[m\]" \
    "\$ " \
  '
fi


0が入力、1が出力、2がエラー
>>リダイレクト追加
grep "[ファイル内文字列検索]" < [sample.txt] > result.txt


```bash
標準出力を標準エラー出力にリダイレクト
echo "error" 1>&2
標準エラー出力を標準出力にリダイレクト
echo "error" 2>&1


標準入力からデータを受け取る
if [ -t 0 ]; then
  echo "stdin is not pipe" 1>&2
  exit 1
else
  cat -
fi | yourcommand
ヒアドキュメント
ヒアドキュメント内のシェル変数は展開される

cat << EOF
This is a heredoc
home is $HOME
EOF

# This is a heredoc
# home is /Users/kohkimakimoto
変数は展開をさせたくないときはコロンで囲む

cat << 'EOF'
This is a heredoc
home is $HOME
EOF

# This is a heredoc
# home is $HOME
ヒアドキュメントの内容を変数に入れる

heredoc=`cat << 'EOF'
This is a heredoc
home is $HOME
EOF`

echo $heredoc
# This is a heredoc
# home is $HOME
ヒアドキュメントの内容をファイルに出力する

cat << 'EOF' > heredocfile
This is a heredoc
home is $HOME
EOF

cat heredocfile
# This is a heredoc
# home is $HOME

```









##############################################
# $ echo "こんにちは" | url_encode
url_encode() {
  nkf -W8MQ |
    sed 's/=$//' |
    tr '=' '%' |
    paste -s -d '\0' - |
    sed -e 's/%7E/~/g' \
        -e 's/%5F/_/g' \
        -e 's/%2D/-/g' \
        -e 's/%2E/./g'
}

# シェルスクリプトらしくない書き方
# むしろシェルスクリプトでは、変数にいちいち結果を代入する方が面倒です。
# 引数で文字列が渡されると仮定
# $ url_encode "こんにちは"

# url_encode() {
#   local input="$*"
#   input="$(echo "$input" | nkf -W8MQ)"
#   input="$(echo "$input" | sed 's/=$//')"
#   input="$(echo "$input" | tr '=' '%')"
#   input="$(echo "$input" | paste -s -d '\0' -)"
#   input="$(echo "$input" | sed -e 's/%7E/~/g' \
#                                -e 's/%5F/_/g' \
#                                -e 's/%2D/-/g' \
#                                -e 's/%2E/./g')"
#   echo "$input"
# }

# 重宝するぞ！ echoとcat
# ところで、コマンドにはsedやgrepのように「標準入力も受け取るし、ファイルパスの指定も受け付ける」という物と、trのように「標準入力からしか入力を受け取らない物」とがあります。でも、どのコマンドがどっちの種類なのかをいちいち覚えるのは煩雑ですよね。こういうバラバラさがシェルスクリプトの嫌な所なんだ、と思う人もいるのではないでしょうか。
#
# でも、実は話は単純なんです。発想を逆転して、基本的に各コマンドへの入力は標準入力から行うものと思っておけばいいんです。
#
# そこで便利なのが、「引数で指定した文字列を標準出力に出力する」コマンドであるechoと、「指定したファイルの内容を標準出力に出力する」コマンドであるcatです。変数に格納された文字列を処理したければechoから、ファイルの内容を処理したければcatからコマンド列を書き始める、という風に覚えておけば、「あれ、このコマンドってファイル指定を受け付けたっけ……？」と悩む必要はありません6。
#
# また、catとヒアドキュメントを併用すれば「シェルスクリプト内に複数行のテキストをリテラルとして埋め込む」ような事もできます。
#
# ヒアドキュメントの内容を標準出力に出力する関数の例
# common_params() {
#   cat << FIN
# oauth_consumer_key $CONSUMER_KEY
# oauth_nonce $(date +%s%N)
# oauth_signature_method HMAC-SHA1
# oauth_timestamp $(date +%s)
# oauth_token $ACCESS_TOKEN
# oauth_version 1.0
# FIN
# }
# 繰り返し処理は配列ではなくイテレータで
# シェルスクリプトでもう一つ鬼門になるのが繰り返し処理です。
#
# 配列のこと、忘れて下さい
# 普通のプログラミングに慣れていると、「繰り返し処理」と「配列」はほぼワンセットで捉えるクセが付いているのではないでしょうか。
#
# しかし、シェルスクリプト……というかBashでの配列の取り扱いは他の言語に比べてやたら面倒です。解説の記事を見ても各要素へのアクセスや長さの取得などで特殊な記法が連発されていて、途中で投げ出したくなることうけあいです。前日の記事のbash-oo-frameworkでも、その実装を見ると配列を簡単に扱えるようにするためにかなりの労力を割いている様子が伺えます。
#
# はい、ここで白状しておきます。筆者はBashの配列を使えません！　Linuxのコマンド操作とシェルスクリプトの基礎を解説する記事のはずのシス管系女子でも、もう連載6年目に突入しようかというのに配列は完全にスルーしています7。拙作TwitterクライアントやTwitter botでも配列は一切使用していません。
#
# じゃあどうやって複数の要素を持つデータを処理するのかという話なんですが、筆者はwhileループとread -rの組み合わせを多用しています。前述の「データは標準入力で受け取って標準出力で出力する」という話とワンセットで覚えておけば、大抵のことはこれでどうにかなってしまいます。シェルスクリプトでは、繰り返し処理はwhileループ（とread -r）でやるのがベストプラクティスと言っていいでしょう。


