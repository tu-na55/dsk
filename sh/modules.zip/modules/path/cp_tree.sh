#!/bin/bash
set -euC

# ディレクトリ構造をコピー
tree | pbcopy
# 以下のような出力をコピー出来る
# /Users/xxx/yyy/
# ├── memo.txt
# ├── dododo.txt
# └── script.rb



##########################################
# 特定拡張子のみツリー表示
tree -P '*.html'

# 除外してツリー表示
tree -I node_modules

# 三階層まで
tree -L 3

# ディレクトリのみ
tree -d
##########################################





