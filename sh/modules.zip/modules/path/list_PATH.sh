#!/bin/bash
set -euC

# パス出力を改行して表示
echo $PATH | tr ":" "\n"
# --出力結果例--
#/usr/local/bin
#/usr/bin
#/bin
#/usr/sbin
#/sbin

