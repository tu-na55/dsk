#!/bin/bash
set -euC

# 更新された日数を指定して探す。
find -mtime 0
# 更新された日数の範囲
find ./work/ -atime 0
find ./work/ -atime -3

# ディレクトリサイズが大きい順で表示
du -m / --max-depth=3 --exclude="/proc*" | sort -k1 -n -r

# 文字列の含まれるファイル名を再帰検索
find PATH -name "*hoge*"


# ファイル名に文字列が含まれるファイルリスト取得
# 指定フォルダのみ
ls search_from_path | grep "search_str"
# 指定フォルダ配下を再帰検索
find search_from_path | type f -name "*search_str"




# ファイル内で文字列が含まれるものリスト
grep search_from_path -rl search_str
# 同じ
find search_from_path -type f -printf | xargs grep "search_str"


# 特定ディレクトリ配下で、ファイル内文字列 '.js'を検索
grep -rn '.js' ./dist/
# 特定kernelを除外して、ファイル内文字列検索
grep -rn '.js' ./ --exclude-dir=.git

なんかできない。
##########################################
# currentで、find -F, grep -vで除外する文字列を指定
# dir
ls -F | grep /
# file
ls -F | grep -v /

find work -name \*.dat
# 省略
find ./work/ *.dat

find ./work/*01* -type d

# 特定文字列で検索
grep hoge `find . -name '*.txt'`

find ./dir/ -name '*' | xargs grep 'keyword'
find . -name '*html' | grep 'portfolio'

# カレントフォルダ(サブフォルダ含む)で特定の文字含むファイル一覧
grep -rnw ./ -e "pattern"

##########################################
# sort
... | sort | unique


# [yyyyMMdd]_[0-9a-zA-Z]\..txt
find . -type f | grep '/*.txt' | sort -n
find . -type f | grep -E "prefix_[0-9a-zA-Z]*\.txt" | sort

##########################################
# xargsで簡単にすむ場合はそうします。
find . -name "*.log" | xargs grep -i error
find . -name "*.log" | while read l;do cp $l $l.back;done

# グロブと合わせたファイル処理はよく使います。
for i in *.log;do cp $i $i.back;done




