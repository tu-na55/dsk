#!/bin/bash
set -euC

# for i in *; do ...; done;技は色々な所で使えて便利
# 見つかったファイルに対して適時シェル実行
# カレントディレクトリ以下のファイルに全て.txtをつけて作成
for val in `find ./*`; do cat $val > $val.txt; done



# リダイレクトの利用
files=()
while read -r f;
do
  files+=("$f")
done <<(find -type f)

echo "${files[@]}"




# listをsortして出力？
declare -a data=(`find . -type f | grep -E "prefix_[0-9a-zA-Z]*\.txt" | sort`)
for k in ${data[@]} ;
do
  val=`echo $k | tr '/' ' ' | awk '{print $3}'`
  echo "${k} ${val}" >> $sortText
done
