#!/bin/bash
set -euC

# 一定容量を持つフォルダを昇順表示
#ルートディレクトリ以下で1~3GBのフォルダ一覧を昇順表示
sudo du -h / | grep  -E '^ *[1-3]+\.?[0-9]+G' | sort



# スクリプトが置かれている場所の絶対パスとスクリプト名を取得
$ echo $(cd $(dirname $0) && pwd)/$(basename $0)
# スクリプト内でフルパスが欲しいときって意外とあるから使うやつ


############################################################
SOURCE="${BASH_SOURCE[0]}"
while [ -h "$SOURCE" ] ; do SOURCE="$(readlink "$SOURCE")"; done
bin_dir="$( cd -P "$( dirname "$SOURCE" )/" && pwd )"
# /usr/local/bin
# などがbin_dirに取得できる

############################################################
# 以下でも良い。
READLINK=$(type -p greadlink readlink | head -1)
if [ -z "$READLINK" ]; then
  echo "cannot find readlink - are you missing GNU coreutils?" >&2
  exit 1
fi

resolve_link() {
  $READLINK "$1"
}

# get absolute path.
abs_dirname() {
  local cwd="$(pwd)"
  local path="$1"

  while [ -n "$path" ]; do
    # cd "${path%/*}" does not work in "$ bash script.sh"
    # cd "${path%/*}"
    cd "$(dirname $path)"
    local name="${path##*/}"
    path="$(resolve_link "$name" || true)"
  done

  pwd -P
  cd "$cwd"
}

bin_dir="$(abs_dirname "$0")"


############################################################
# シンボリックに対応しないなら、以下の記述でもOK。
# スクリプトがシンボリックリンクから呼び出されたときは、リンクを辿らず、リンク先のパスを返す
bin_dir=$(cd $(dirname $0); pwd)
