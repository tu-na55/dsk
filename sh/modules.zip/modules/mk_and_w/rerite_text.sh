##########################################
# ファイル内文字列書き換え
for i {1..2}
do
  if [[ -e "$file" ]]; then
    sed -e -i "s/hoge/" "$file"
    echo "$file"
  fi
done

exit0
