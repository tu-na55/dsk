ディレクトリ作成後そこへ移動
$ mkdir dir_name ; cd $_