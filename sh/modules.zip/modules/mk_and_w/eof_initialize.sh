#!/bin/bash
set -euC

cat << "_EOF_" > ./init.txt
# initialization

_EOF_







