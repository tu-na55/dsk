#!/bin/bash
set -euC

cat input.csv | awk 'BEGIN {FS=","; OFS=","} {print $2,$3}' > output.csv


