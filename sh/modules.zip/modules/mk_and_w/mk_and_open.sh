#!/bin/bash
set -euC

#　新規ファイルを作成するディレクトリ
DESKTOP_DIR=~/Desktop

#　同名のファイルが有れば、そのファイル名＋1とする
cnt=`ls ${DESKTOP_DIR} | grep newtext | grep -v grep | grep txt |  wc -l`
fcnt=`echo $cnt`
if [ "$fcnt" -gt 0 ]; then
  FILENAME=${DESKTOP_DIR}/newtext_${fcnt}.txt
else
  FILENAME=${DESKTOP_DIR}/newtext.txt
fi

# touchコマンドｄ新規テキストを作成
touch ${FILENAME}

#　作成したファイルをテキストエディタで開く。下記の場合では「CotEditor」を使用
open ${FILENAME} -a /Applications/CotEditor.app

exit