#!/bin/bash
set -euC

# Note:
# osxとlinuxで挙動が違う。
# どちらでもひとまず動くバージョン
# linuxだとプリフィクスの末尾に"X"が必要でここがランダムな文字列に置き換わる。
# osxだとXがリプレースされずそのまま使用され、その後にランダムな文字列が追加される

# 一時ファイルを作成
tmpfile=$(mktemp -t prefix.XXXXXXXX)
echo $tmpfile

# 終了時に一時ファイルを削除
trap "rm $tmpfile" 0


# 一時ディレクトリを作成
# tmpdir=$(mktemp -d -t prefix.XXXXXXXX)
# echo $tmpdir

# 終了時に一時ディレクトリを削除
# trap "rm -rf  $tmpdir" 0







