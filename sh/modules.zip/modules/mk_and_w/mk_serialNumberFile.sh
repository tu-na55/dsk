
touch foo_{1..30}.txt

touch {A..Z}.txt
