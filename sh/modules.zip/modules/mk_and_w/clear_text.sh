#!/bin/bash
set -euC

# ファイルを空にする
# sample.txtというファイルを空にする

# 01
cat /dev/null > sample.txt

# 02
cp /dev/null sample.txt

ファイルを空にする
cat /dev/null > sample.txt
一々テキストエディタ開いて削除とかいらない便利なやつ


# 03
echo -n > sample.txt






