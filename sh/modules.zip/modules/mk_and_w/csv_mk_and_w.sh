#!/bin/bash
set -euC

makeFile() {

  # mkdir -p
  # 指定したパスを子階層も含めてすべて生成する
  # 既にディレクトリがある場合はエラーにもならず無視される
  # 既存ディレクトリの有無を確認してからmkdirする必要がない
  # mkdir -p test2/dir1 test2がない場合は作成。

  # 複数ファイル、フォルダを一括作成等
  # sample.txt, sample1.txt, sample2.txt sample3.txtをまとめて作成
  # touch sample{,1,2,3}.txt

  # /taiyop/以下にdir_a,dir_b,dir_cのフォルダを作成
  # mkdir /taiyop/dir_{a,b,c}
  # mkdir {a,b,c,d,e}


  # make
  # mkdir -pv $name
  # ls -ld $name

  # 更新ファイル順でsort
  # touch $name
  # ls -lt

  mkdir -pv $distPath

  if [[ ! -e "${inputFileList}" ]] ; then
    find ./src/ -type f | grep -E "*\.txt" | sort -n > $inputFileList
  else
    rm -v $inputFileList
    find ./src/ -type f | grep -E "*\.txt" | sort -n > $inputFileList
  fi


  if [[ ! -e "${outputFile}" ]] ; then
    echo $columnNames > $outputFile
  else
    rm -v $outputFile
    echo $columnNames > $outputFile
  fi

}


### main ###
distPath = "./dist/"
inputFileList = ${distPath}'inputFileList.txt'
outputFile = ${distPath}'output.csv'
columnNames = 'key,name,msg'

# func
makeFile

data = `cat $inputFileList`
count = 0

while IFS= read -r line;
do
  count `expr $count + 1`
  echo $count: $line

  key = `echo $count`
  path = `echo $line`
  msg = `sed -n 2P $line`
  record = `echo -n "${key}" "${path}" | tr ' ' ','; echo "${msg}"`
  echo $record

  echo $record >> $outputFile
  echo -ne "\n"

# done < input.txt
done <<INPUT
  $data
INPUT

trap "echo -n fin." EXIT
exit 0



