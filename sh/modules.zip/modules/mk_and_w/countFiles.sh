#!/bin/bash
set -euC

# 任意のディレクトリのファイル数をカウント
ls -F | grep -v / | wc -l

# カレントディレクトリ以下のファイル数
# find . -type f | wc -l










