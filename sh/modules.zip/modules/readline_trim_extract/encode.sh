

# 文字コード変換
perl -MEncode -pe '$_ = encode("utf8", decode("eucjp", $_))' eucjp.txt > utf.txt


nkf -sW binary_shiftJIS.txt