#!/bin/bash
set -euC

# ファイルの中をソートして重複行を削除
# sample.txtの重複行を削除
sort sample.txt -uo sample.txt

# ソートしないで重複行を削除する
# sample.txtの重複行削除
awk '!val[$0]++' sample.txt



# sortとuniqのイディオム
$ .. | sort | uniq -c | sort -nr
