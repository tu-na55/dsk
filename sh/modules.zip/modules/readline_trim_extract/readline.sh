#!/bin/bash
set -euC

ask() {
    local response
    # call with a prompt string or use a default
    read -r -p "${1:->} " response
    echo $response
}
# 使い方
# v=$(ask)
# echo $v

# >
# と表示されて入力待ち状態になる。入力値はvに入る。

# プロンプトの表示も買えられる
# v=$(ask "[input your name]> ")
# echo $v


ask() {
  echo "キーボードから文字を入力してください..."
  read DATA

  echo ""
  echo "入力されたデータ: $DATA"

  echo ""
  echo "<Enter>で終了します。"

  # readコマンドをスクリプトの一時停止に利用する
  read DUMMY

  echo "終了します..."

  exit 0
}



