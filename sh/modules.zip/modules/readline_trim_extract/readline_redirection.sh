#!/bin/bash
set -euC

echo "while文にリダイレクション"

# readコマンドで標準入力から1行読み込む
while read line
do
  echo "$line"
done <$1

echo "カレントシェルにリダイレクション"

# exec コマンドを使用しカレントシェルの標準入力へリダイレクトする
exec <$1

# readコマンドで標準入力から1行読み込む
while read line
do
  echo "$line"
done

exit 0

################
# $ ./redirection.sh test.txt
