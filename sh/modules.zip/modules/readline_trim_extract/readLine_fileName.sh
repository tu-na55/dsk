#!/bin/bash
set -euC

inputPath = `echo PWD'/dirName/'`

echo -n 'fileName: '
read base

cat "${inputPath}${base}"

# sleep 1
# read DUMMY
echo ""
echo -n "done."
exit 0



