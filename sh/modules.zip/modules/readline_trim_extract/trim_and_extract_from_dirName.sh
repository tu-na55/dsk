#!/bin/bash
set -euC

# find
inputPath = './l1/l2/l3/20190909_01/data.txt'

# awk '{print $NF}'を使わない
base = `basename ${inputPath}`
echo -e "base: ${base}\n"

# 文字列を複数の引数に分割して、任意の引数を表示
target = `echo $inputPath | tr '/' ' ' | awk '{print $4}'`
# グループ以外除去
echo $target | sed -e "s/^[0-9]\._\([0-9]\.\)/\1/g"



# ヘッダーとフッターを除外して表示
$ cat ファイル名 | sed -e '$d' | awk 'NR > 1 {print}'
