#!/bin/bash
set -euC

# sdiff of sidebysideは使いづらかった。
# git形式
diff -wuy a.txt b.txt







