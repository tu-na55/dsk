#!/bin/bash
set -euC

# 「str1」「atr2」の「」を除去
cat input.xml | grep -oP '(?<=「).+(?=」)'
cat input.xml | awk -F '[「」]' 'NF=2{print $2}'
# REVIEW
cat input.xml | sed -nr '/「/{s/.*「//g;s/」 .*//gp}'


# xmlタグ内のテキスト取得
grep -Eo '<tag>(.*?)<\/tag>' input.xml
grep -E -m 1 -o "<title>(.*)</title>" input.xml

# 複数タイトルを取得
sed -e 's,.*<title>\([^<]*\)</title>.*,\1,g'



