#!/bin/bash
set -euC

# 表示される行数
ls | wc -l

# プロセス名で検索し、grepを邪魔しないようにする
ps aux | grep java | grep -v grep



###########################################
# 3行目のみ表示
sed -n '3p' file

# 5行目を取り出す
sed input.txt -e "5,5p" -e d

# 2行目を表示
awk 'NR==2' input.txt

# 文字数カウント(wc -c)
$ awk '{n+=length($0)} END{print n}' filename

# 単語数カウント(wc -w)
$ awk '{n+=NF} END{print n}' filename

# 行数カウント(wc -l)
$ awk 'END{print NR}' filename


指定行から指定行まで表示
$ awk 'NR==10,NR==20'

奇数/偶数行のみ表示
# 奇数行
$ awk 'NR%2' filename

# 偶数行
$ awk 'NR%2==0' filename

###########################################
# 複数パターン検索
grep "aaa\|bbb" test.txt

# 任意の文字列を含む行を抽出
# shiftJIS => utf-8
grep 'wards' <(nkf -Sw input.txt)

# 複数行抽出される場合、行を指定。
grep 'words' input.txt | awk 'NR==2'

# "abc"にマッチした行の次の次の行を取り出す例
sed -n -e '/abc/{n;n;p;}'

# 前後5行表示、ログ調査時によく使う
grep -C5 'error' log/target.log

# input.txtの3行目から5行目まで出力してoutput.txtに上書き
tail -n +3 input.txt | head -n 4 > output.txt

###########################################
# マッチした部分のみ表示する
# 圧縮ファイル解凍せず検索するzgrep
# zgrep 'test' file_name
zgrep -ro --color 'rand=' sitemaps/

# 特定のファイルの文字列のみ検索
# _keywordのviewファイルのみ文字列を検索する
find app/views/users2019/ -name "*_keyword*" | xargs grep 'content_for :title'

# grep で#で始まるコメント行および空白行を削除する
grep -v -e '^\s*#' -e '^\s*$' filename





