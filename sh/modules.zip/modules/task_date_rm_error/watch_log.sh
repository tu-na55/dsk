# アクセスログをリアルタイムに表示する
$ tail -f access_log | grep --line-buffered 'test'

# シスログを時間指定で見る
$ awk -F - '"開始時間" < $1 && $1 <= "終了時間"' /抽出を行うログのPATH
