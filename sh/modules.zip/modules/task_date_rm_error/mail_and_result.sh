#!/bin/bash
set -euC

MAILTO='hoge@example.com'
RESULT=｀bash -e main.sh`

if [ $? -ne 0 ] ; then
  echo "${RESULT}"| mail -s "error at ｀hostname｀" ${MAILTO}
fi




