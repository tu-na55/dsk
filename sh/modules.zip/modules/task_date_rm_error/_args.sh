#!/bin/bash
set -euC


  # mkdir -p
  # function hoge() {
  #   dif fuga (){
  #     dif init () {
  #       return 0
  #     }
  #   }
  # }
  # mv -n, cp -n


+ 変数の空白保持

```bash
VAL1=

# これだと構文エラー。左辺がない状態。
if [ $VAL -eq 1 ]; then echo "ok"; fi

# これと同等
if [ -eq 1 ]; then echo "ok"; fi


# なので、変数を扱うならこうする。
if [ "$VAL1" -eq 1 ]; then echo "ok"; fi

```

```bash
# 変数の値に半角スペースがあると、コマンド引数やループなどのときにスペース区切りで値が分解されてしまいます。

# 2つのファイル名として認識される。
FILE_NAME="so what"

cp $FILE_NAME ./mydir/
cp some text file.txt ./mydir/
# これだとファイルがなくて、エラーになる。

```


```bash

for file in *.txt; do
# `*.txt`にマッチするファイルが無い場合に、file='*.txt'としてループが１回処理されるのでチェック
  if [ ! -e "$file" ]; then continue; fi

  echo $file
done

```
___


```bash
# if文はこうする
if [[ $VAL == '' ]]; then echo "OK"; fi
# 変数に""がないけど じゃないけど、エラーにならず、"OK"と表示される
```

```bash
# コマンドやfunctionに渡された引数の全てを保持する「$@」という特殊変数を使う時は、必ず「"」で囲ってください。 値に半角スペースを含む場合に囲うかどうかで挙動が変わってしまいます。

for i in $@; do echo $i; done


```


```bash

# 以下のフォーマットは任意。

function func1() {
  local arg1="$1"
  echo hello "$arg1"
}

```



コマンドの戻り値を取得する ($?)
[ "aaa" = "bbb" ]
echo $?
# 1

パイプでつないだコマンドの戻り値を取得する (${PIPESTATUS[0]})
$?は最後に実行されたコマンドの戻り値なので、前述のindent関数などをパイプでつなげた場合、もとの実行コマンドの戻り値は取れない。この場合はPIPESTATUSを使う。

[ "aaa" = "bbb" ] | indent; status=${PIPESTATUS[0]}
echo $status
# 1
参考: パイプでつないだコマンドの戻り値を調べる＠bash | Mazn.net








