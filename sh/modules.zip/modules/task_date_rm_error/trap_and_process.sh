#!/bin/bash
set -euC




# スクリプトのロック(多重起動防止)
exec 9< $0
perl -mFcntl=:flock -e "open(LOCK,'<&=9');exit(!flock(LOCK,LOCK_EX|LOCK_NB))" || {
    echo "duplicate process." >&2
    exit 1
}

# trapコマンドでシグナルをハンドリング
echo "start"
trap "echo 'after end'" 0
echo "end"


###### trap
$ trap 'echo trapped.' 2
※ ここで Ctrl+c を押す。
$ trapped.
#↑trap に指定した処理が実行されている。

$ trap 2
#↑trap をリセットする。
※ ここで Ctrl+c を押す。
$
#↑指定した処理が解除されているのが確認できる。

___
trap 'command' 1 2 3 15
→ 通常の用途では trap するシグナルは 1, 2 , 3, 15 のみでよい。


```bash
#!/bin/bash

# ゴミ掃除用の trap 処理を指定する。
trap 'echo "trapped."; rm -f temp.$$; exit 1' 1 2 3 15

# trap時に削除するファイルを作成する。
echo "Trap Test." >temp.$$
echo "作成されたファイルを確認する。"
ls -l temp.$$

# Ctrl+cが押されるまで無限ループ。
echo "Ctrl+cを押してください。"
while :
do
  :
done
```
このシェルスクリプト trap_rm.sh の実行結果は、以下のとおりとなる。

$ ./trap_rm.sh
作成されたファイルを確認する。
-rw-r--r-- 1 sunone sunone 11  6月 2日 14:01 temp.9535
Ctrl+cを押してください。
※ ここで Ctrl+c を押す。
trapped.
#↑トラップ処理が実行されている。

$ ls temp.9535
/bin/ls: temp.9535: そのようなファイルやディレクトリはありません
#↑トラップ処理によりファイルが削除されていることが確認できる。
___
trap コマンドの応用 2
trap 'command' 0 といったように0番を指定しても結果は同じになるが、この trap 処理が終了処理であることが明確に分かる EXIT を指定するようにした方がよい。


```bash
#!/bin/bash

# EXITシグナルをtrapして終了メッセージを指定する。
trap "echo '`basename $0`を終了します.'" EXIT

# 他のシグナルもtrapしておく。
trap "echo '他のシグナルをtrapしました。'" 1 2 3 15

# Ctrl+Cで終了するテストのためにsleepしておく。
sleep 10

exit 0
```
このシェルスクリプト trap_exit.sh の実行結果は、以下のとおりとなる。

$ ./trap_exit.sh
trap_exit.shを終了します.
#↑終了時に EXIT シグナルを trap したメッセージが表示されている。

$ ./trap_exit.sh
※ ここで Ctrl+c を押す。
他のシグナルをtrapしました。
trap_exit.shを終了します.
#↑INT シグナルで終了した場合も EXIT シグナルは trap できる。
このテクニックは exit するルートが複数存在し、かつ終了時に共通の処理を行う必要があるシェルスクリプトにおいては非常に有効である。



#####################################



