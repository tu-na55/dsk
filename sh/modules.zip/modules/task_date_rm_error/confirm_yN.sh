#!/bin/bash
set -euC

confirm() {
    local response
    # call with a prompt string or use a default
    read -r -p "${1:-Are you sure? [y/N]:} " response
    case $response in
        [yY][eE][sS]|[yY])
            return 0
            ;;
        *)
            return 1
            ;;
    esac
}

# 使い方
# confirm
# if [ $? -ne 0 ]; then
#     exit 1
# fi
# Are you sure? [y/N]:
# と表示されて入力まちになるのでyやyesを入力で続行。それ以外はexitする。

# 引数で表示メッセージを変えられる。
# confirm "Please input yes!:"

# set -eしておけばconfirmの戻りが1のとき即終了するのであと条件分岐を書く必要がない
# set -e
# confirm
