# ストップウォッチ
time read
# Ctrl + Dを押したら止まる。