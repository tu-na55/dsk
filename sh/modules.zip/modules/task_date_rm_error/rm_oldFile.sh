#!/bin/bash
set -euC

find ./path/to/log -name '*.log' -mtime +30 -delete







