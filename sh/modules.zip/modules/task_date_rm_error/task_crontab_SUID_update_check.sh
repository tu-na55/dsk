#!/bin/bash
set -euC

20 15 * * 3 root find / -perm -u+s
