
# プロセスIDを取得する($$)
echo $$
# 99807

# 任意のプロセスが動いているか確認
# mysqlのプロセスが動いているか確認
ps aux | grep mysql

プロセス名で一括kill
$ kill `ps -aux | grep "プロセス名" | awk '{print $2;}'`

物理メモリを多く使用しているプロセスを抽出
$ ps aux | sort -n -k 6 | tail -n 10

CPU使用率が高いプロセスを見つける
$ vmstat 1 | awk '{print strftime("%y/%m/%d %H:%M:%S"), $0}'


定期的にプロセス状態を監視
$ while true ; do ps aux | grep httpd ; echo ""; sleep 2 ; done ;
watchあるならそっちでも。ログ見やすいから個人的にはこっち


タイムスタンプつきでtailf
tailf file | while read; do echo "$(date +%T.%N) $REPLY"; done

表示整形 column
$ mount | column -t
セパレータを指定することもできる

grepする時間を指定して出力がなければエラー終了
$ timeout 5 tailf hoge.txt | grep -q --line-buffered "hoge"

ユーザ毎のCPU使用率を見る
$ ps aux | awk '{ if(NR>1){p[$1] += $3; n[$1]++ }}END{for(i in p) print p[i], n[i], i}'

