#!/bin/bash
set -euC

# .bash_rc

### [PROMPT_COMMAND] ###
# 複数のことをPROMPT_COMMANDで行おうとすると、
# export PROMPT_COMMAND="hogehoge; ${PROMPT_COMMAND}"
# とPROMPT_COMMANDに追記していくようになるのですが、注意しないと、.bashrcの再読読み込み. .bashrcとしたときなど、以前のPROMPT_COMMANDが残ってしまうことがあります。
# PROMPT_COMMANDにはディスパッチ処理のみを登録し、個別の処理は、PROMPT_COMMAND_hogehogeに設定します。

dispatch () {
        export EXIT_STATUS="$?"
         # 直前のコマンド実行結果のエラーコードを保存

        local f
        for f in ${!PROMPT_COMMAND_*}; do
        #${!HOGE*}は、HOGEで始まる変数の一覧を得る

            eval "${!f}"
            # "${!f}"は、$fに格納された文字列を名前とする変数を参照する（間接参照）

        done
        unset f
}
export PROMPT_COMMAND="dispatch"
