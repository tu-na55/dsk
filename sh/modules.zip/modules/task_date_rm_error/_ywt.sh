#!/bin/bash
set -euC

### commit ###

# inputPath = `echo PWD'/dirName/'`

echo -n 'task: '
read taskS

# TODO: date.format
d = date

echo -n 'Y: '
read y
echo ""
echo -n 'W: '
read w
echo ""
echo -n 'T: '
read t

# TODO: redirect



# cat "${inputPath}${base}"/

# sleep 1
# read DUMMY
echo ""
echo -n "done."
exit 0



