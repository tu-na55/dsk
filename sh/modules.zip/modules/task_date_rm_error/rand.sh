#!/bin/bash
set -euC

echo $RANDOM
# 出力結果例：273


# ランダム文字列を生成
head /dev/urandom | shasum |cut -f 1 -d ' '


パスワードをランダム生成する
$ head /dev/urandom | tr -dc A-Za-z0-9 | head -c 13 ; echo ''
テストユーザとかのパスワードが必要なときにとりあえず



