Listen中のポート一覧
$ lsof -Pan -i tcp -i udp
ssでもいい気がするがこっちも

指定したポートを使ってるプロセスをkill
$ lsof -i :8080 | awk '{l=$2} END {print l}' | xargs kill
