# 適当なリポジトリで以下を実行すると過去365日に1日ずつ空コミットのログを作成します。
# pushすると365日毎日コミットした（してない）コミットログがプッシュされ、GitHubにたくさん草が生えます。

for i in {1..365} ;
do d=`LANG=C date -v-${i}d "+%a %b %d %H:%M:%S %Y -0900"`;
git commit --allow-empty -m "YEAH" --date="$d"; done

