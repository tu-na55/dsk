#!/bin/bash
set -euC

# エラーメッセージを出して終了する
abort() {
  { if [ "$#" -eq 0 ]; then cat -
    else echo "${txtred}${progname}: $*${txtreset}"
    fi
  } >&2
  exit 1
}

# 使い方
# abort "error message"
