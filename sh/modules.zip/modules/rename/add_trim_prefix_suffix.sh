#!/bin/bash
set -euC

# 01 間違ってるかも？
# 追加
find $PATH -type f -print0 | awk -F/ '{print $NF}' | xargs -I% mv PATH/% PATH/prefix_%
find $PATH -type f -print0 | xargs -0 -I% mv PATH/% PATH/%_suffix

# 削除
find $PATH -type f -print0 -name 'prefix_' | perl -pe 's/preffix_//g' | xargs -0 -I% mv prefix_*% %
find $PATH -type f -print0 -name '_suffix' | perl -pe 's/_suffix//g' | xargs -0 -I% mv %*_suffix %


# 02
prefix() {
  local p="${1:-prefix}"
  local c="s/^/$p/"
  case $(uname) in
    Darwin) sed -l "$c";; # mac/bsd sed: -l buffers on line boundaries
    *)      sed -u "$c";; # unix/gnu sed: -u unbuffered (arbitrary) chunks of data
  esac
}

# 使い方
echo "message" | prefix "[hoge] "
# [hoge] message

# 標準エラー出力も対象とする場合はエラーを標準出力にリダイレクトしてから行う
echo "message" 2>&1 | prefix "[hoge] "
