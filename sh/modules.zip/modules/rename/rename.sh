#!/bin/bash
set -euC

find . -type f | sed 'p;s/\.txt/\.sh/' | xargs -n2 mv
