#!/bin/bash
set -euC

# 標準出力にインデントをつける
indent() {
    local n="${1:-4}"
    local p=""
    for i in `seq 1 $n`; do
        p="$p "
    done;

    local c="s/^/$p/"
    case $(uname) in
      Darwin) sed -l "$c";; # mac/bsd sed: -l buffers on line boundaries
      *)      sed -u "$c";; # unix/gnu sed: -u unbuffered (arbitrary) chunks of data
    esac
}

# 使い方
# デフォルトで4スペースインデント
echo "message" | indent
#    message

# インデントサイズを引数に渡せる
echo "message" | indent 6
#      message
