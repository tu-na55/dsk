#!/bin/bash
set -euC

# 改行コード
cat input.txt | tr "\r\n" "\n" > output.txt


# uppercase, lowercase
# 実はこれだけでいい
echo {$line,,}

# 02
#input.txtの小文字 -> 大文字でoutput.txtに上書き
cat input.txt | tr '[a-z]' '[A-Z]' > output.txt
#input.txtの大文字 -> 小文字でoutput.txtに上書き
cat input.txt | tr '[a-z]' '[A-Z]' > output.txt

# 03
upper() {
    echo -n "$1" | tr '[a-z]' '[A-Z]'
}
# 使い方
v=$(upper "abcdefg")
echo $v



# n進数->10進数変換
# 2進数
echo $((2#101))
# 16進数
echo $((16#afaf))




