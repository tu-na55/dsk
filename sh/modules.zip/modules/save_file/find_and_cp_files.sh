
# あるディレクトリ配下のファイルを一括コピー
$ for txt in $(find . -name *.txt); do cp -ip ${txt} ~/work/ ; done

