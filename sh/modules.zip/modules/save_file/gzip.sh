
# k: stay org.file
# c: standard-I/O

echo "str" | gzip -c > save.txt.gz

# 解凍
gzip -dk save.txt.gz