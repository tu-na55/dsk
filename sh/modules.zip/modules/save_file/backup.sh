

バックアップ
$ cp passwd{,.bak}