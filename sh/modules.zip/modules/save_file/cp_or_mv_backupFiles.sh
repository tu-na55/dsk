#!/bin/bash
set -euC

# TODO: ${date}_backup

# mv -v, cp -v, rm -v
# 多くのコマンドは -vをつけるとコマンドの実行ログ出力される
# mv, cp, rmはそれぞれのファイル操作の元・先のファイルを表示するので動作結果を確認できる

# mv -n, cp -n
# ファイル操作系のコマンドに-nオプションを付けると上書き防止になる
# 移動先、コピー先に既に同名のファイルがあった場合にエラー終了する

# cp -b [to_sample.txt] [to_sample.txt] 同名ファイルが有る場合、バックアップを取ってからコピー。
# cp -uは上書きコピー
# cp -rp [from_dir] [to_dil] ディレクトリ属性の保持


# 既存ファイルをバックアップ
mkdir backup
mv a.txt b.txt c.txt backup/


# 任意のディレクトリ以下の画像ファイルを見つけて指定したディレクトリに全てコピー
# pictureフォルダ以下のjpgファイルを見つけてデスクトップ以下にコピー
find ./picture -name '*.jpg' | xargs -J% cp -f % ./cpy